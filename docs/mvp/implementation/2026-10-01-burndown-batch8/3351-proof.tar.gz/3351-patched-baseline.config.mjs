import {readFileSync} from "node:fs";
import original from "/private/tmp/smithers-burndown-20260930/packages/smithers/agent/registry/vitest.config.ts";
const codes=JSON.parse(readFileSync("/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2/3351-patched-baseline-inputs.json","utf8"));
export default {...original,plugins:[{name:"verified-baseline-production-seam-overlay",enforce:"pre",transform(source,id){return codes[id.split("?")[0]];}}],test:{...original.test,coverage:{enabled:false}}};
